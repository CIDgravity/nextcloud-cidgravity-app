# Security Policy

## Reporting a Vulnerability

### Non Critical Vulnerabilities:
Open a Github issue

### Critical Vulnerabilities:
Send a mail to: contact@cidgravity.com