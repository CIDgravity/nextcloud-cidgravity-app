const babelConfig = require('@nextcloud/babel-config')

module.exports = babelConfig
